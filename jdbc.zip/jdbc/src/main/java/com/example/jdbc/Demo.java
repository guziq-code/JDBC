package com.example.jdbc;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Demo {
    public static void main(String[] args) throws Exception{

        String sql = "SELECT lastname from Student where personid =1";


        String url = "jdbc:postgresql://localhost:5432/guzik";
        String username = "postgres";
        String password = "pacany96";
        Connection con = DriverManager.getConnection(url, username, password);
        Statement st = con.createStatement();
        st.executeQuery(sql);
        ResultSet rs = st.executeQuery(sql);
        rs.next();
        String name = rs.getString(1);
        System.out.println(name);



    }
}
